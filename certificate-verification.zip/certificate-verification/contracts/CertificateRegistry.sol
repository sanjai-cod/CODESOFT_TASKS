// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title CertificateRegistry
/// @notice Decentralised registry for issuing and verifying academic certificates.
/// @dev Records are write-once: there is no update or delete function, so issued
///      certificates are tamper-proof. Verification is a read-only (view) call.
contract CertificateRegistry {
    struct Certificate {
        string studentName;
        string certificateId;
        string courseName;
        uint256 issueDate; // Unix timestamp
        address issuedBy;
        bool exists;
    }

    address public owner;
    mapping(address => bool) public isAdmin;

    // keccak256(certificateId) => Certificate
    mapping(bytes32 => Certificate) private certificates;
    uint256 public totalCertificates;

    event CertificateIssued(
        string certificateId,
        string studentName,
        string courseName,
        uint256 issueDate,
        address indexed issuedBy
    );
    event AdminAdded(address indexed admin);
    event AdminRemoved(address indexed admin);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    modifier onlyOwner() {
        require(msg.sender == owner, "Caller is not the owner");
        _;
    }

    modifier onlyAuthorized() {
        require(msg.sender == owner || isAdmin[msg.sender], "Caller is not authorized");
        _;
    }

    constructor() {
        owner = msg.sender;
        emit OwnershipTransferred(address(0), msg.sender);
    }

    // ---------------------------------------------------------------------
    // Access control
    // ---------------------------------------------------------------------

    function addAdmin(address admin) external onlyOwner {
        require(admin != address(0), "Invalid address");
        require(!isAdmin[admin], "Already an admin");
        isAdmin[admin] = true;
        emit AdminAdded(admin);
    }

    function removeAdmin(address admin) external onlyOwner {
        require(isAdmin[admin], "Not an admin");
        isAdmin[admin] = false;
        emit AdminRemoved(admin);
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Invalid address");
        emit OwnershipTransferred(owner, newOwner);
        owner = newOwner;
    }

    // ---------------------------------------------------------------------
    // Issuance (owner / admins only)
    // ---------------------------------------------------------------------

    /// @notice Register a new certificate. Reverts if the ID already exists.
    function issueCertificate(
        string calldata studentName,
        string calldata certificateId,
        string calldata courseName,
        uint256 issueDate
    ) external onlyAuthorized {
        require(bytes(studentName).length > 0, "Student name required");
        require(bytes(certificateId).length > 0, "Certificate ID required");
        require(bytes(courseName).length > 0, "Course name required");
        require(issueDate > 0, "Issue date required");

        bytes32 key = keccak256(bytes(certificateId));
        require(!certificates[key].exists, "Certificate ID already exists");

        certificates[key] = Certificate({
            studentName: studentName,
            certificateId: certificateId,
            courseName: courseName,
            issueDate: issueDate,
            issuedBy: msg.sender,
            exists: true
        });
        totalCertificates += 1;

        emit CertificateIssued(certificateId, studentName, courseName, issueDate, msg.sender);
    }

    // ---------------------------------------------------------------------
    // Verification (read-only, free, open to everyone)
    // ---------------------------------------------------------------------

    /// @notice Fetch and validate a certificate by its unique ID.
    /// @return valid True if the certificate exists
    function verifyCertificate(string calldata certificateId)
        external
        view
        returns (
            bool valid,
            string memory studentName,
            string memory courseName,
            uint256 issueDate,
            address issuedBy
        )
    {
        Certificate storage c = certificates[keccak256(bytes(certificateId))];
        if (!c.exists) {
            return (false, "", "", 0, address(0));
        }
        return (true, c.studentName, c.courseName, c.issueDate, c.issuedBy);
    }

    /// @notice Lightweight existence check.
    function isCertificateValid(string calldata certificateId) external view returns (bool) {
        return certificates[keccak256(bytes(certificateId))].exists;
    }

    /// @notice Check that a certificate exists AND belongs to the given student/course.
    function verifyDetails(
        string calldata certificateId,
        string calldata studentName,
        string calldata courseName
    ) external view returns (bool) {
        Certificate storage c = certificates[keccak256(bytes(certificateId))];
        return c.exists
            && keccak256(bytes(c.studentName)) == keccak256(bytes(studentName))
            && keccak256(bytes(c.courseName)) == keccak256(bytes(courseName));
    }
}
