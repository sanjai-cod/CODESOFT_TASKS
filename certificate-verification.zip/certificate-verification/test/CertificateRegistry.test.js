const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("CertificateRegistry", function () {
  let registry, owner, admin, outsider;

  const records = [
    { name: "Arun Kumar", id: "CERT-2024-001", course: "B.E. Electrical and Electronics Engineering", date: 1717200000 },
    { name: "Priya Lakshmi", id: "CERT-2024-002", course: "B.E. Computer Science", date: 1717286400 },
    { name: "Karthik Raja", id: "CERT-2024-003", course: "M.E. Power Systems", date: 1717372800 },
    { name: "Divya Bharathi", id: "CERT-2024-004", course: "Diploma in Embedded Systems", date: 1717459200 },
  ];

  beforeEach(async function () {
    [owner, admin, outsider] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory("CertificateRegistry");
    registry = await Factory.deploy();
    await registry.waitForDeployment();
  });

  async function issueAll(signer = owner) {
    for (const r of records) {
      await registry.connect(signer).issueCertificate(r.name, r.id, r.course, r.date);
    }
  }

  it("sets deployer as owner", async function () {
    expect(await registry.owner()).to.equal(owner.address);
  });

  it("issues and verifies multiple certificates", async function () {
    await issueAll();
    expect(await registry.totalCertificates()).to.equal(records.length);

    for (const r of records) {
      const res = await registry.verifyCertificate(r.id);
      expect(res.valid).to.equal(true);
      expect(res.studentName).to.equal(r.name);
      expect(res.courseName).to.equal(r.course);
      expect(res.issueDate).to.equal(r.date);
      expect(res.issuedBy).to.equal(owner.address);
    }
  });

  it("emits CertificateIssued event", async function () {
    const r = records[0];
    await expect(registry.issueCertificate(r.name, r.id, r.course, r.date)).to.emit(
      registry,
      "CertificateIssued"
    );
  });

  it("rejects duplicate certificate IDs", async function () {
    const r = records[0];
    await registry.issueCertificate(r.name, r.id, r.course, r.date);
    await expect(
      registry.issueCertificate("Someone Else", r.id, "Other Course", r.date)
    ).to.be.revertedWith("Certificate ID already exists");
    expect(await registry.totalCertificates()).to.equal(1);
  });

  it("returns invalid for unknown certificate IDs", async function () {
    await issueAll();
    const res = await registry.verifyCertificate("CERT-FAKE-999");
    expect(res.valid).to.equal(false);
    expect(res.studentName).to.equal("");
    expect(await registry.isCertificateValid("CERT-FAKE-999")).to.equal(false);
  });

  it("verification does not modify state", async function () {
    await issueAll();
    const before = await registry.totalCertificates();
    await registry.verifyCertificate(records[1].id);
    await registry.isCertificateValid(records[1].id);
    expect(await registry.totalCertificates()).to.equal(before);

    const fn = registry.interface.getFunction("verifyCertificate");
    expect(fn.stateMutability).to.equal("view");
  });

  it("verifyDetails matches only correct student and course", async function () {
    const r = records[2];
    await registry.issueCertificate(r.name, r.id, r.course, r.date);
    expect(await registry.verifyDetails(r.id, r.name, r.course)).to.equal(true);
    expect(await registry.verifyDetails(r.id, "Wrong Name", r.course)).to.equal(false);
    expect(await registry.verifyDetails(r.id, r.name, "Wrong Course")).to.equal(false);
  });

  it("validates required fields", async function () {
    await expect(registry.issueCertificate("", "ID1", "Course", 1)).to.be.revertedWith("Student name required");
    await expect(registry.issueCertificate("Name", "", "Course", 1)).to.be.revertedWith("Certificate ID required");
    await expect(registry.issueCertificate("Name", "ID1", "", 1)).to.be.revertedWith("Course name required");
    await expect(registry.issueCertificate("Name", "ID1", "Course", 0)).to.be.revertedWith("Issue date required");
  });

  describe("access control (bonus)", function () {
    it("blocks non-authorized accounts from issuing", async function () {
      const r = records[0];
      await expect(
        registry.connect(outsider).issueCertificate(r.name, r.id, r.course, r.date)
      ).to.be.revertedWith("Caller is not authorized");
    });

    it("lets owner add an admin who can then issue", async function () {
      await expect(registry.addAdmin(admin.address)).to.emit(registry, "AdminAdded").withArgs(admin.address);
      await issueAll(admin);
      const res = await registry.verifyCertificate(records[0].id);
      expect(res.issuedBy).to.equal(admin.address);
    });

    it("only owner can add or remove admins", async function () {
      await expect(registry.connect(outsider).addAdmin(outsider.address)).to.be.revertedWith(
        "Caller is not the owner"
      );
      await registry.addAdmin(admin.address);
      await expect(registry.connect(admin).removeAdmin(admin.address)).to.be.revertedWith(
        "Caller is not the owner"
      );
    });

    it("removed admin loses issuing rights", async function () {
      await registry.addAdmin(admin.address);
      await registry.removeAdmin(admin.address);
      const r = records[0];
      await expect(
        registry.connect(admin).issueCertificate(r.name, r.id, r.course, r.date)
      ).to.be.revertedWith("Caller is not authorized");
    });

    it("anyone can verify, even without a role", async function () {
      await issueAll();
      const res = await registry.connect(outsider).verifyCertificate(records[3].id);
      expect(res.valid).to.equal(true);
    });

    it("owner can transfer ownership", async function () {
      await registry.transferOwnership(admin.address);
      expect(await registry.owner()).to.equal(admin.address);
      await expect(registry.addAdmin(outsider.address)).to.be.revertedWith("Caller is not the owner");
    });
  });
});
