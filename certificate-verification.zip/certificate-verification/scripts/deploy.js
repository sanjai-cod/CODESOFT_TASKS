const { ethers } = require("hardhat");

async function main() {
  const Factory = await ethers.getContractFactory("CertificateRegistry");
  const registry = await Factory.deploy();
  await registry.waitForDeployment();
  console.log("CertificateRegistry deployed to:", await registry.getAddress());

  // Demo: issue and verify a sample certificate
  const now = Math.floor(Date.now() / 1000);
  await (await registry.issueCertificate("Sample Student", "CERT-DEMO-001", "B.E. EEE", now)).wait();
  const res = await registry.verifyCertificate("CERT-DEMO-001");
  console.log("Verify CERT-DEMO-001 ->", res.valid, res.studentName, res.courseName);
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
