# Student Certificate Verification (Blockchain)

A Solidity smart contract that issues and verifies academic certificates on-chain,
with no centralized database.

## Features
- Stores student name, certificate ID, course name, issue date (and issuer address)
- `verifyCertificate(id)` – free, read-only (`view`) lookup by unique certificate ID
- Duplicate certificate IDs are rejected
- Records are write-once (no update/delete) → tamper-proof; every issuance emits an event
- **Bonus:** only the owner or admins added by the owner can issue certificates

## Contract API
| Function | Access | Description |
|---|---|---|
| `issueCertificate(name, id, course, date)` | owner / admin | Register a certificate |
| `verifyCertificate(id)` | anyone (view) | Returns `(valid, name, course, date, issuedBy)` |
| `isCertificateValid(id)` | anyone (view) | Boolean existence check |
| `verifyDetails(id, name, course)` | anyone (view) | Confirms details match the record |
| `addAdmin / removeAdmin` | owner | Manage administrators |
| `transferOwnership(newOwner)` | owner | Hand over ownership |

## Run
```bash
npm install
npx hardhat compile
npx hardhat test
npx hardhat run scripts/deploy.js      # in-process demo
```
Or deploy via [Remix IDE](https://remix.ethereum.org): paste `contracts/CertificateRegistry.sol`,
compile with 0.8.20+, deploy, and call functions from the UI.

## Tests
`test/CertificateRegistry.test.js` covers: issuing 4 certificates, verification,
duplicate rejection, unknown IDs, read-only verification, field validation,
admin add/remove, unauthorized issuance, and ownership transfer.
