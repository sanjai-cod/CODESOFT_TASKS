const { ethers } = require("hardhat");

async function main() {
  const [me] = await ethers.getSigners();
  const todo = await (await ethers.getContractFactory("TodoList")).deploy();
  await todo.waitForDeployment();
  console.log("TodoList deployed to:", await todo.getAddress());

  await (await todo.addTask("Learn Solidity")).wait();
  await (await todo.addTask("Build a dApp")).wait();
  await (await todo.setTaskStatus(0, true)).wait();
  console.log("Tasks:", (await todo.getTasks(me.address)).map((t) => [t.id, t.description, t.completed]));
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
