// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title TodoList
/// @notice Decentralised personal task manager. Each wallet manages its own tasks.
contract TodoList {
    struct Task {
        uint256 id;
        string description;
        bool completed;
        uint256 createdAt;   // block timestamp when created
        uint256 completedAt; // block timestamp when completed (0 if pending)
    }

    // user => taskId => Task
    mapping(address => mapping(uint256 => Task)) private tasks;
    // user => list of that user's active task ids (in creation order)
    mapping(address => uint256[]) private taskIds;
    // user => taskId => (index in taskIds + 1); 0 means "does not exist"
    mapping(address => mapping(uint256 => uint256)) private idPosition;
    // user => next task id to assign
    mapping(address => uint256) private nextTaskId;

    event TaskCreated(address indexed user, uint256 indexed id, string description, uint256 createdAt);
    event TaskStatusUpdated(address indexed user, uint256 indexed id, bool completed);
    event TaskCompleted(address indexed user, uint256 indexed id, uint256 completedAt);
    event TaskDeleted(address indexed user, uint256 indexed id);

    modifier taskExists(uint256 id) {
        require(idPosition[msg.sender][id] != 0, "Task does not exist");
        _;
    }

    // ------------------------------------------------------------------
    // Write functions (affect only msg.sender's tasks)
    // ------------------------------------------------------------------

    /// @notice Add a new pending task.
    function addTask(string calldata description) external returns (uint256 id) {
        require(bytes(description).length > 0, "Description required");

        id = nextTaskId[msg.sender]++;
        tasks[msg.sender][id] = Task({
            id: id,
            description: description,
            completed: false,
            createdAt: block.timestamp,
            completedAt: 0
        });
        taskIds[msg.sender].push(id);
        idPosition[msg.sender][id] = taskIds[msg.sender].length; // index + 1

        emit TaskCreated(msg.sender, id, description, block.timestamp);
    }

    /// @notice Mark a task as completed (true) or pending (false).
    function setTaskStatus(uint256 id, bool completed) external taskExists(id) {
        Task storage t = tasks[msg.sender][id];
        require(t.completed != completed, "Status unchanged");

        t.completed = completed;
        t.completedAt = completed ? block.timestamp : 0;

        emit TaskStatusUpdated(msg.sender, id, completed);
        if (completed) {
            emit TaskCompleted(msg.sender, id, block.timestamp);
        }
    }

    /// @notice Delete a task. Only completed tasks can be deleted.
    function deleteTask(uint256 id) external taskExists(id) {
        require(tasks[msg.sender][id].completed, "Only completed tasks can be deleted");

        // swap-and-pop keeps the id array compact
        uint256[] storage ids = taskIds[msg.sender];
        uint256 index = idPosition[msg.sender][id] - 1;
        uint256 lastId = ids[ids.length - 1];

        ids[index] = lastId;
        idPosition[msg.sender][lastId] = index + 1;
        ids.pop();

        delete idPosition[msg.sender][id];
        delete tasks[msg.sender][id];

        emit TaskDeleted(msg.sender, id);
    }

    // ------------------------------------------------------------------
    // Read functions
    // ------------------------------------------------------------------

    /// @notice Get all tasks belonging to a wallet address.
    /// @dev Blockchain data is public; anyone can read any address's tasks.
    function getTasks(address user) external view returns (Task[] memory) {
        uint256[] storage ids = taskIds[user];
        Task[] memory result = new Task[](ids.length);
        for (uint256 i = 0; i < ids.length; i++) {
            result[i] = tasks[user][ids[i]];
        }
        return result;
    }

    /// @notice Convenience: tasks of the caller.
    function getMyTasks() external view returns (Task[] memory) {
        return this.getTasks(msg.sender);
    }

    /// @notice Get a single task of a wallet.
    function getTask(address user, uint256 id) external view returns (Task memory) {
        require(idPosition[user][id] != 0, "Task does not exist");
        return tasks[user][id];
    }

    /// @notice Number of active (non-deleted) tasks of a wallet.
    function getTaskCount(address user) external view returns (uint256) {
        return taskIds[user].length;
    }
}
