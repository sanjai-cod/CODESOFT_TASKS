# To-Do List Smart Contract

Decentralized task manager in Solidity. Every wallet manages its own tasks.

## Data model
- `struct Task { id, description, completed, createdAt, completedAt }`
- `mapping(address => mapping(uint256 => Task))` – tasks per wallet
- `mapping(address => uint256[])` – per-wallet task id list (for retrieval)
- `mapping(address => mapping(uint256 => uint256))` – id → position, enabling O(1) delete (swap-and-pop)

## Functions
| Function | Description |
|---|---|
| `addTask(description)` | Add a pending task; stores `block.timestamp` |
| `setTaskStatus(id, completed)` | Mark completed (`true`) or pending (`false`) |
| `deleteTask(id)` | Delete a task — **completed tasks only** |
| `getTasks(address)` | All tasks of a wallet |
| `getMyTasks()` | All tasks of the caller |
| `getTask(address, id)` | One task |
| `getTaskCount(address)` | Number of active tasks |

Events: `TaskCreated`, `TaskStatusUpdated`, `TaskCompleted`, `TaskDeleted`.

## Test on Remix IDE
1. Open https://remix.ethereum.org, create `TodoList.sol`, paste `contracts/TodoList.sol`.
2. **Solidity Compiler** tab → version 0.8.20 or newer → Compile.
3. **Deploy & Run** tab → Environment: *Remix VM (Cancun)* → Deploy `TodoList`.
4. Try, in order:
   - `addTask` → `"Buy milk"`, then `addTask` → `"Study Solidity"`
   - `getTasks` → paste your account address (copy it from the Account dropdown): shows both tasks with timestamps
   - `setTaskStatus` → `0, true` → check the `TaskStatusUpdated` and `TaskCompleted` events in the terminal logs
   - `deleteTask` → `1` → reverts (task still pending)
   - `deleteTask` → `0` → succeeds, `TaskDeleted` emitted
   - `getTaskCount` → your address → `1`
   - Switch to a different account and call `getTasks` for the first address: tasks are readable by anyone, but the second account cannot modify them (`Task does not exist`).

## Automated tests (optional)
```bash
npm install
npx hardhat test
```
