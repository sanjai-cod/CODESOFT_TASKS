const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("TodoList", function () {
  let todo, alice, bob;

  beforeEach(async function () {
    [alice, bob] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory("TodoList");
    todo = await Factory.deploy();
    await todo.waitForDeployment();
  });

  it("adds tasks with description, pending status and timestamp", async function () {
    await expect(todo.connect(alice).addTask("Buy groceries")).to.emit(todo, "TaskCreated");
    const tasks = await todo.getTasks(alice.address);
    expect(tasks.length).to.equal(1);
    expect(tasks[0].id).to.equal(0);
    expect(tasks[0].description).to.equal("Buy groceries");
    expect(tasks[0].completed).to.equal(false);
    expect(tasks[0].createdAt).to.be.gt(0);
    expect(tasks[0].completedAt).to.equal(0);
  });

  it("rejects empty descriptions", async function () {
    await expect(todo.addTask("")).to.be.revertedWith("Description required");
  });

  it("assigns sequential ids per user", async function () {
    await todo.connect(alice).addTask("A1");
    await todo.connect(alice).addTask("A2");
    await todo.connect(bob).addTask("B1");
    const a = await todo.getTasks(alice.address);
    const b = await todo.getTasks(bob.address);
    expect(a.map((t) => Number(t.id))).to.deep.equal([0, 1]);
    expect(b.map((t) => Number(t.id))).to.deep.equal([0]);
  });

  it("updates status to completed and back to pending", async function () {
    await todo.addTask("Write report");
    await expect(todo.setTaskStatus(0, true))
      .to.emit(todo, "TaskStatusUpdated").withArgs(alice.address, 0, true);

    let t = await todo.getTask(alice.address, 0);
    expect(t.completed).to.equal(true);
    expect(t.completedAt).to.be.gt(0);

    await todo.setTaskStatus(0, false);
    t = await todo.getTask(alice.address, 0);
    expect(t.completed).to.equal(false);
    expect(t.completedAt).to.equal(0);
  });

  it("emits TaskCompleted when a task is completed", async function () {
    await todo.addTask("Ship it");
    await expect(todo.setTaskStatus(0, true)).to.emit(todo, "TaskCompleted");
  });

  it("rejects unchanged status and unknown tasks", async function () {
    await todo.addTask("Task");
    await expect(todo.setTaskStatus(0, false)).to.be.revertedWith("Status unchanged");
    await expect(todo.setTaskStatus(99, true)).to.be.revertedWith("Task does not exist");
  });

  it("keeps each user's tasks separate", async function () {
    await todo.connect(alice).addTask("Alice task");
    await expect(todo.connect(bob).setTaskStatus(0, true)).to.be.revertedWith("Task does not exist");
    expect(await todo.getTaskCount(bob.address)).to.equal(0);
  });

  it("retrieves all tasks of a given address", async function () {
    await todo.connect(alice).addTask("One");
    await todo.connect(alice).addTask("Two");
    await todo.connect(alice).addTask("Three");
    const tasks = await todo.getTasks(alice.address);
    expect(tasks.map((t) => t.description)).to.deep.equal(["One", "Two", "Three"]);
    expect(await todo.getTaskCount(alice.address)).to.equal(3);
    const mine = await todo.connect(alice).getMyTasks();
    expect(mine.length).to.equal(3);
  });

  describe("deleting (bonus)", function () {
    it("cannot delete a pending task", async function () {
      await todo.addTask("Pending");
      await expect(todo.deleteTask(0)).to.be.revertedWith("Only completed tasks can be deleted");
    });

    it("deletes a completed task and emits TaskDeleted", async function () {
      await todo.addTask("Done");
      await todo.setTaskStatus(0, true);
      await expect(todo.deleteTask(0)).to.emit(todo, "TaskDeleted").withArgs(alice.address, 0);
      expect(await todo.getTaskCount(alice.address)).to.equal(0);
      await expect(todo.getTask(alice.address, 0)).to.be.revertedWith("Task does not exist");
    });

    it("keeps remaining tasks intact after deleting from the middle", async function () {
      await todo.addTask("T0");
      await todo.addTask("T1");
      await todo.addTask("T2");
      await todo.setTaskStatus(0, true);
      await todo.deleteTask(0);

      const tasks = await todo.getTasks(alice.address);
      expect(tasks.length).to.equal(2);
      expect(tasks.map((t) => t.description).sort()).to.deep.equal(["T1", "T2"]);

      // remaining tasks are still updatable and deletable
      await todo.setTaskStatus(2, true);
      await todo.deleteTask(2);
      await todo.setTaskStatus(1, true);
      await todo.deleteTask(1);
      expect(await todo.getTaskCount(alice.address)).to.equal(0);
    });

    it("does not reuse ids after deletion", async function () {
      await todo.addTask("First");
      await todo.setTaskStatus(0, true);
      await todo.deleteTask(0);
      await todo.addTask("Second");
      const tasks = await todo.getTasks(alice.address);
      expect(tasks[0].id).to.equal(1);
    });
  });
});
