# Compile, Deploy, and Test in Remix IDE

## A. Compile
1. Visit https://remix.ethereum.org.
2. In **File Explorer**, create `SimpleStorage.sol`.
3. Copy the full source code from this project's `SimpleStorage.sol` into the Remix editor.
4. Open **Solidity Compiler**.
5. Select compiler `0.8.20` (or a compatible Solidity `0.8.x` version).
6. Click **Compile SimpleStorage.sol**. A successful compile shows no compiler errors.

## B. Deploy to a local simulated blockchain
1. Open **Deploy & Run Transactions**.
2. Select **Remix VM** for the environment.
3. Ensure `SimpleStorage` is selected as the contract.
4. Click **Deploy**.
5. Under **Deployed Contracts**, expand `SimpleStorage`.

## C. Test the functions
1. Click `storedValue` or `getValue` → expected output: `0`.
2. Enter `10` in the `setValue` input and click the button → transaction succeeds.
3. Click `storedValue` or `getValue` → expected output: `10`.
4. Enter `25` in the `updateValue` input and click the button.
5. Click `getValue` → expected output: `25`.
6. Click `increment` → then `storedValue` returns `26`.
7. Click `decrement` → then `storedValue` returns `25`.
8. Set the value to `0`, then click `decrement`. The transaction should fail/revert with `Value cannot be decremented below zero`.
9. Check the transaction receipt/logs for the `ValueChanged` event after successful changes.

## D. What to submit
- `SimpleStorage.sol` — source code.
- `README.md` — project overview and quick start.
- `FUNCTIONS_AND_OUTPUTS.md` — function descriptions and expected outputs.
- `TESTING_GUIDE.md` — compile/deploy/test instructions.

## Important
This project includes instructions for testing but has not been deployed to a public blockchain. Follow the steps above to compile and test it in Remix VM.
