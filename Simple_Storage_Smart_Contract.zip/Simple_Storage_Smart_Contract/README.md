# Simple Storage Smart Contract

## Overview
This beginner-friendly Solidity project stores one non-negative integer on a blockchain. It demonstrates a public state variable, write/read functions, events, input validation, compilation, deployment, and testing.

## Files
- `SimpleStorage.sol` — smart contract source.
- `TESTING_GUIDE.md` — steps to compile, deploy, and test using Remix IDE.
- `FUNCTIONS_AND_OUTPUTS.md` — function descriptions and expected outputs.

## Quick start with Remix IDE
1. Open https://remix.ethereum.org in a browser.
2. Create a file named `SimpleStorage.sol` and paste in the code from this project.
3. Open **Solidity Compiler**, select compiler version `0.8.20` or a compatible `0.8.x` version, then click **Compile SimpleStorage.sol**.
4. Open **Deploy & Run Transactions**.
5. Choose **Remix VM** as the environment and click **Deploy**.
6. Expand the deployed contract and use the buttons to test the functions.

The contract uses `uint256`, so values are whole numbers from `0` through `2^256 - 1`. Negative values are not accepted by the type system. `decrement()` explicitly rejects a value of zero.

## Example
- Initial `storedValue`: `0`
- `setValue(10)` → stored value becomes `10`
- `increment()` → stored value becomes `11`
- `decrement()` → stored value becomes `10`
- `getValue()` → returns `10`

## Notes
- In Remix VM, deployment and transactions use a local simulated blockchain; no real funds are needed.
- Write functions change blockchain state and require a transaction. Read functions do not change state.
- Each successful change emits a `ValueChanged` event containing the old value, new value, and caller address.
