// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title SimpleStorage
/// @notice Stores one integer and provides functions to manage it.
contract SimpleStorage {
    // Public state variable: Solidity automatically creates a getter named getValue is not needed.
    uint256 public storedValue;

    /// @notice Emitted whenever the stored value changes.
    event ValueChanged(uint256 oldValue, uint256 newValue, address indexed changedBy);

    /// @notice Set the stored value to a new non-negative integer.
    function setValue(uint256 _newValue) public {
        uint256 oldValue = storedValue;
        storedValue = _newValue;
        emit ValueChanged(oldValue, _newValue, msg.sender);
    }

    /// @notice Update the stored value. Included as a clear alias for setValue.
    function updateValue(uint256 _newValue) public {
        uint256 oldValue = storedValue;
        storedValue = _newValue;
        emit ValueChanged(oldValue, _newValue, msg.sender);
    }

    /// @notice Return the current stored value.
    function getValue() public view returns (uint256) {
        return storedValue;
    }

    /// @notice Increase the stored value by one.
    function increment() public {
        require(storedValue < type(uint256).max, "Value cannot be incremented further");
        uint256 oldValue = storedValue;
        storedValue += 1;
        emit ValueChanged(oldValue, storedValue, msg.sender);
    }

    /// @notice Decrease the stored value by one. Prevents underflow at zero.
    function decrement() public {
        require(storedValue > 0, "Value cannot be decremented below zero");
        uint256 oldValue = storedValue;
        storedValue -= 1;
        emit ValueChanged(oldValue, storedValue, msg.sender);
    }
}
