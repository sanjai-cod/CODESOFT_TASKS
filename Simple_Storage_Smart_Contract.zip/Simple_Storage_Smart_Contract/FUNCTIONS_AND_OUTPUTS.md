# Functions and Expected Outputs

The contract starts with `storedValue = 0`.

| Function | Type | Purpose | Example | Expected result |
|---|---|---|---|---|
| `storedValue()` | Read (automatic public getter) | Read the public state variable | Call after deployment | `0` |
| `setValue(uint256)` | Write | Set the value | `setValue(10)` | `storedValue` becomes `10` |
| `updateValue(uint256)` | Write | Update the value using an alternate function | `updateValue(25)` | `storedValue` becomes `25` |
| `getValue()` | Read | Return the current value | Call after setting 25 | `25` |
| `increment()` | Write | Add one | Current value is 25 | Value becomes `26` |
| `decrement()` | Write | Subtract one | Current value is 26 | Value becomes `25` |

## Event
Every successful set, update, increment, or decrement emits:

`ValueChanged(oldValue, newValue, changedBy)`

- `oldValue`: value before the change
- `newValue`: value after the change
- `changedBy`: address that submitted the transaction

## Validation
- `uint256` accepts only unsigned whole numbers, so negative integers cannot be passed.
- `decrement()` uses `require(storedValue > 0, ...)`; trying to decrement zero reverts with `Value cannot be decremented below zero`.
- `increment()` checks the maximum `uint256` value before adding one to avoid overflow.

## Sample test sequence
1. Deploy → `storedValue()` returns `0`.
2. Call `setValue(10)` → `storedValue()` returns `10`.
3. Call `updateValue(25)` → `getValue()` returns `25`.
4. Call `increment()` → `storedValue()` returns `26`.
5. Call `decrement()` → `storedValue()` returns `25`.
6. Call `setValue(0)`, then call `decrement()` → transaction reverts with the validation message.
